Starting structures (protein coordinates) are provided as pdb files:
- Y4R_SRS_Gi_conf.pdb
- Y4R_RSR_Gi_conf.pdb
- Y4R_hPP_Gi_conf.pdb
- Y1R_pNPY_Gi_conf.pdb
- Y2R_pNPY_Gi_conf.pdb
- V2R_AVP_Gs_conf.pdb
- OTR_OT_Gq_conf.pdb
Plumed input file to run MW-MetaD with binding/unbinding CV is provided (plumed.dat) for the Y4R-SRS-Gi system.
32 representative structures of the Y4R-SRS-Gi system were extracted from a short MetaD to initialise each walker. The system coordinates are provided as pdb files.




