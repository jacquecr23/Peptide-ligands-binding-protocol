Plumed input file to run MW-MetaD with binding/unbinding CV is provided (plumed.dat).
32 representative structures were extracted from a short MetaD to initialise each walker. The system coordinates are provided as pdb files.




